package edu.snhu.cs320.task;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
    private final Map<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {
        if (task == null || tasks.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Invalid task");
        }
        tasks.put(task.getTaskId(), task);
    }

    public void deleteTask(String id) {
        if (!tasks.containsKey(id)) {
            throw new IllegalArgumentException("Task not found");
        }
        tasks.remove(id);
    }

    public void updateTask(String id, String name, String desc) {
        Task t = tasks.get(id);
        if (t == null) throw new IllegalArgumentException("Task not found");
        t.setName(name);
        t.setDescription(desc);
    }

    protected Map<String, Task> getTasks() {
        return tasks;
    }
}