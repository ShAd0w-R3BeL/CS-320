package edu.snhu.cs320.task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddTask() {
        TaskService service = new TaskService();
        Task t = new Task("1", "Code", "JUnit Tests");
        service.addTask(t);
        assertEquals(t, service.getTasks().get("1"));
    }

    @Test
    void testDeleteTask() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Task", "Desc"));
        service.deleteTask("1");
        assertFalse(service.getTasks().containsKey("1"));
    }

    @Test
    void testUpdateTask() {
        TaskService service = new TaskService();
        service.addTask(new Task("1", "Initial", "Desc"));
        service.updateTask("1", "NewName", "NewDesc");
        assertEquals("NewName", service.getTasks().get("1").getName());
    }
}