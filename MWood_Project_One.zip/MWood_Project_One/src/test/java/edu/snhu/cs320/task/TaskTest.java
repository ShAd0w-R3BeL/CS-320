package edu.snhu.cs320.task;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testTaskClassSuccess() {
        Task task = new Task("1", "Project One", "Submit to SNHU");
        assertAll("Task State",
            () -> assertEquals("1", task.getTaskId()),
            () -> assertEquals("Project One", task.getName()),
            () -> assertEquals("Submit to SNHU", task.getDescription())
        );
    }

    @Test
    void testTaskIdValidation() {
        // Requirement: ID not null and <= 10 characters
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Name", "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Name", "Desc"));
    }

    @Test
    void testNameValidation() {
        Task task = new Task("1", "Name", "Desc");
        // Requirement: Name not null and <= 20 characters
        assertThrows(IllegalArgumentException.class, () -> task.setName(null));
        assertThrows(IllegalArgumentException.class, () -> task.setName("This name is way more than twenty characters long"));
    }

    @Test
    void testDescriptionValidation() {
        Task task = new Task("1", "Name", "Desc");
        // Requirement: Description not null and <= 50 characters
        assertThrows(IllegalArgumentException.class, () -> task.setDescription(null));
        assertThrows(IllegalArgumentException.class, () -> task.setDescription("This description is definitely going to be longer than the fifty character limit allowed."));
    }
}