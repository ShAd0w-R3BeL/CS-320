package edu.snhu.cs320.appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentServiceTest {
    private final Date futureDate = new Date(System.currentTimeMillis() + 86400000);

    @Test
    void testAddAppointment() {
        AppointmentService service = new AppointmentService();
        Appointment appt = new Appointment("1", futureDate, "Meeting");
        service.addAppointment(appt);
        assertEquals(appt, service.getAppointments().get("1"));
    }

    @Test
    void testDeleteAppointment() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(new Appointment("1", futureDate, "Meeting"));
        service.deleteAppointment("1");
        assertTrue(service.getAppointments().isEmpty());
    }
}