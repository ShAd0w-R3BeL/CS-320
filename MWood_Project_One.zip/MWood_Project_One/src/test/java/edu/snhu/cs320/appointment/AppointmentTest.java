package edu.snhu.cs320.appointment;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.Date;

public class AppointmentTest {
    private final Date futureDate = new Date(System.currentTimeMillis() + 86400000);

    @Test
    void testAppointmentCreationSuccess() {
        Appointment appt = new Appointment("123", futureDate, "Desc");
        assertEquals("123", appt.getAppointmentId());
        assertEquals(futureDate, appt.getAppointmentDate());
    }

    @Test
    void testAppointmentIdValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment(null, futureDate, "Desc"));
        assertThrows(IllegalArgumentException.class, () -> new Appointment("12345678901", futureDate, "Desc"));
    }

    @Test
    void testAppointmentDateValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", null, "Desc"));
        Date pastDate = new Date(System.currentTimeMillis() - 86400000);
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", pastDate, "Desc"));
    }

    @Test
    void testAppointmentDescriptionValidation() {
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", futureDate, null));
        String longDesc = "This description is definitely way too long for the fifty character limit.";
        assertThrows(IllegalArgumentException.class, () -> new Appointment("1", futureDate, longDesc));
    }
}